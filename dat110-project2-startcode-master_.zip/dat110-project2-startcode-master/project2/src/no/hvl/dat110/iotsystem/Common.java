package no.hvl.dat110.iotsystem;

public class Common {

	public static String TEMPTOPIC = "temperature";
	public static int BROKERPORT = 8080;
	public static String BROKERHOST = "localhost";
}
